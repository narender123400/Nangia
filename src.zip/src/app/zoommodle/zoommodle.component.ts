import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zoommodle',
  templateUrl: './zoommodle.component.html',
  styleUrls: ['./zoommodle.component.scss']
})
export class ZoommodleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
