import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { DatabaseService } from "../src/app/database.service";
import { DialogComponent } from './DialogComponent';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  // DbUrl:string = "http://nextstep.net.in/nangia/index.php/";
  DbUrl:string = "http://crm.nangia.com/nangia_api/index.php/";
  
  constructor(private http: HttpClient,public db:DatabaseService,public dialoge:DialogComponent) { }
  
  auth:any = {};
  
  ngOnInit(){
    this.auth.token='';
    console.log(this.auth);
  }
  
  login(username: string, password: string): Observable<boolean> {
    console.log(username);
    console.log(password);
    
    let request_data={username:username,password:password};
    
    return this.http.post<{token: string}>(this.DbUrl+'login/user_login', JSON.stringify(request_data))
    .pipe(
      map((result:any) => {
        console.log(result);
        this.auth.token = result.token;
        // this.auth.result = result.data;
        //this.db.header = result.token
        // this.db.token = result.token;
        localStorage.setItem('access_token', result.token);
        localStorage.setItem('access_result', JSON.stringify(result.data));
        console.log("this is OLD token");
        console.log(localStorage);
        
        
        
        if(localStorage.access_token=="")
        {
          this.dialoge.error("Invalid ! Password");
          // return true;  
        }
        else
        {
          return true;
          // this.dialoge.error("wrong312312");
        }    
      })
      );
    }
    
    public get loggedIn(): boolean {
      
      return (localStorage.getItem('access_token') !== null);
    }
  }
  