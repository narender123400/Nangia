import { Component, OnInit } from '@angular/core';
//import { SessionserviceService } from "../sessionservice.service";
import {FormControl, Validators,FormGroup,FormBuilder} from '@angular/forms';
import { DatabaseService } from "../database.service";
import { Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { AuthService } from "../auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

  form:any = {};
  input_type:any = '';
  loginForm: FormGroup;
  public error: string;
  submitted = false;
  hide = true;

  constructor(private formBuilder: FormBuilder,public db:DatabaseService,private auth: AuthService,private router: Router) { }

  ngOnInit() {

    this.input_type = 'password';
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  get f() { return this.loginForm.controls; }

  public login() 
  {
    this.submitted = true; 
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    else
    {
      this.auth.login(this.loginForm.value.username, this.loginForm.value.password)
      .pipe(first())
      .subscribe(
        result => {
          let resp_result = JSON.parse(localStorage.getItem('access_result'));
          console.log(resp_result);
          this.router.navigate(['/dashboard']);
         
          
          },
        err => this.error = 'Could not authenticate'
      );
    }
  }
}
