import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AuthService } from "../app/auth.service";
import { AuthgurdService } from "../app/gaurd/authgurd.service";

import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ReactiveFormsModule,FormsModule } from "@angular/forms";
import { HttpClientModule,HttpClient } from '@angular/common/http';

import { LoginComponent } from './login/login.component';
import { MaterialModule } from './material';
import { HeaderComponent } from './header/header.component';
import { KnowledgeDocComponent } from './knowledge/knowledge-doc/knowledge-doc.component';
import { KnowledgeListComponent } from './knowledge/knowledge-list/knowledge-list.component';
import { CategoryModalComponent } from './knowledge/category-modal/category-modal.component';
import { SubCategoryModalComponent } from './knowledge/sub-category-modal/sub-category-modal.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { UserDetailComponent } from './user/user-detail/user-detail.component';
import { EdituserComponent } from './user/edituser/edituser.component';
import { KnowledgeDetailComponent } from './knowledge/knowledge-detail/knowledge-detail.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddCategoryComponent } from './Category/add-category/add-category.component';
import { CategoryListComponent } from './Category/category-list/category-list.component';
import { AddCategoryModuleComponent } from './Category/add-category-module/add-category-module.component';
import { AddSubCategoryModuleComponent } from './Category/add-sub-category-module/add-sub-category-module.component';
import { MydocumentComponent } from './mydocument/mydocument.component';
import { MydocdetailComponent } from './mydocdetail/mydocdetail.component';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { KnowledgeEditComponent } from './knowledge/knowledge-edit/knowledge-edit.component';
import { UserDownloadsComponent } from './user-downloads/user-downloads.component';
import { MyDownloadComponent } from './my-download/my-download.component';
import { MyUploadComponent } from './my-upload/my-upload.component';
import { KnowledgeRequestModalComponent } from './knowledge/knowledge-request-modal/knowledge-request-modal.component';


const routes: Routes = [
    {path: "", component:LoginComponent},
    {path: "login", component:LoginComponent},
    { path: "knowledge-doc", component: KnowledgeDocComponent,canActivate:[AuthgurdService]  , data: { expectedRole: [1,2] } },
    { path: "knowledge-edit/:id", component: KnowledgeEditComponent,canActivate:[AuthgurdService]},
    { path: "knowledge-list", component: KnowledgeListComponent ,canActivate:[AuthgurdService]  , data: { expectedRole: [1,2] } },
    { path: "knowledge-detail/:id", component: KnowledgeDetailComponent ,canActivate:[AuthgurdService]},
    { path: "knowledge-detail/:id/:user_id", component: KnowledgeDetailComponent ,canActivate:[AuthgurdService]},
    { path: "add-user", component: AddUserComponent,canActivate:[AuthgurdService]},
    { path: "user-list", component: UserListComponent,canActivate:[AuthgurdService]},
    { path: "user-detail/:id", component: UserDetailComponent,canActivate:[AuthgurdService]},
    { path: "edituser/:id", component: EdituserComponent,canActivate:[AuthgurdService]},
    { path: "dashboard", component: DashboardComponent,canActivate:[AuthgurdService]},
    {path: "category-list", component:CategoryListComponent,canActivate:[AuthgurdService]},
    {path: "add-category", component:AddCategoryComponent,canActivate:[AuthgurdService]},
    {path: "mydocument", component:MydocumentComponent,canActivate:[AuthgurdService]},
    {path: "mydocdetail/:id", component:MydocdetailComponent,canActivate:[AuthgurdService]},

    {path: "user-download-list", component:UserDownloadsComponent,canActivate:[AuthgurdService]},
    {path: "my-download", component:MyDownloadComponent,canActivate:[AuthgurdService]},
    {path: "my-download/:id", component:MyDownloadComponent,canActivate:[AuthgurdService]},
    {path: "my-upload", component:MyUploadComponent,canActivate:[AuthgurdService]}
    
];


@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        HeaderComponent,
        KnowledgeDocComponent,
        KnowledgeListComponent,
        CategoryModalComponent,
        SubCategoryModalComponent,
        AddUserComponent,
        UserListComponent,
        UserDetailComponent,
        EdituserComponent,
        KnowledgeDetailComponent,
        DashboardComponent,
        AddCategoryComponent,
        CategoryListComponent,
        AddCategoryModuleComponent,
        AddSubCategoryModuleComponent,
        MydocumentComponent,
        MydocdetailComponent,
        KnowledgeEditComponent,
        UserDownloadsComponent,
        MyDownloadComponent,
        MyUploadComponent,
        KnowledgeRequestModalComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MaterialModule,
        RouterModule,
        RouterModule.forRoot(routes),
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
        AutocompleteLibModule
        
    ],

    entryComponents: [
        CategoryModalComponent,
        SubCategoryModalComponent,
        AddCategoryModuleComponent,
        AddSubCategoryModuleComponent,
        KnowledgeRequestModalComponent
      ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
