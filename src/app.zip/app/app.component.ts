import { Component } from '@angular/core';
import {AuthService  } from "../app/auth.service";
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'nangia';

  constructor(private auth: AuthService,private router: Router)
  {
    console.log(this.auth.auth);    
  }
}
