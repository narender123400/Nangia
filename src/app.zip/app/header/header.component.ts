import { Component, OnInit, Renderer2 } from '@angular/core';
import { DatabaseService } from "../database.service";
import { Router } from '@angular/router';
import { AuthService } from "../auth.service";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {

  show_tabs:any;
  constructor(private renderer: Renderer2,public db:DatabaseService, public router: Router, private auth: AuthService) {
    
   }

  status:boolean = false;
  toggleHeader() {
      this.status = !this.status;
      if(this.status) {
          this.renderer.addClass(document.body, 'active');
      }
      else {
          this.renderer.removeClass(document.body, 'active');
      }
  }
  show_actions:any={};

  ngOnInit() {    
    let resp_result = JSON.parse(localStorage.getItem('access_result'));
          console.log(resp_result);
      this.show_tabs = resp_result.access_level;
      this.db.FetchData({'userid': resp_result.id},'User/get_user')
          .subscribe((result:any)=>{
            console.log(result);
            this.db.permission_array = result.data;
            this.show_actions.add_document=result.data.add_document;            
          },error=>{
            console.log(error);
          });
  }

  logout() 
  {
      this.auth.auth={};
      localStorage.removeItem('access_token');
      this.router.navigate(['']);
  }

}
