import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { DatabaseService } from "../database.service";
import { AuthService } from "../auth.service";
@Injectable({
  providedIn: 'root'
})
export class AuthgurdlogService implements CanActivate {

  constructor(private router: Router, public db: DatabaseService,public auth: AuthService) {
    console.log('Auth Guard Log');
   }

   canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    
    this.router.navigate(['login']);
    return false;
    
    
  }
}
