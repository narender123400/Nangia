import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from "../auth.service";
import { DatabaseService } from "../database.service";

@Injectable({
  providedIn: 'root'
})
export class AuthgurdService implements CanActivate{

  constructor(private router: Router,public auth: AuthService,public db: DatabaseService) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (localStorage.getItem('access_token')) {
      this.db.token = localStorage.getItem('access_token');
      this.auth.auth.token = this.db.token;
      return true;
    }

    else
    {
      this.router.navigate([''], { queryParams: { returnUrl: state.url }});
      return false;
    }
  }
}
