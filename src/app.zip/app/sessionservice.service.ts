import { Injectable } from '@angular/core';
import { DatabaseService } from "../app/database.service";
import { Observable, of } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { DialogComponent } from './DialogComponent';


@Injectable({
  providedIn: 'root'
})
export class SessionserviceService {

  constructor(public route: ActivatedRoute, public router:Router, public db:DatabaseService, public dialog:DialogComponent) { }

  nangia_user:any = {};


  ngOnInit()
  {
    this.nangia_user.nangia_login = false;
    console.log(this.nangia_user);
  }

  GetSession():   Observable<any>
  {

    this.nangia_user = JSON.parse(localStorage.getItem('nangia_user')) || [];
    console.log(this.nangia_user);
    return of(this.nangia_user);
  }

  LogOutSession()
  {
    this.nangia_user = {};
    this.nangia_user.nangia_login = false;
    this.db.can_active = '';
    localStorage.removeItem('nangia_user');
  }

  NextUrl:any = '';
  SetSession(data:any){
    this.NextUrl = this.route.snapshot.queryParams['returnUrl'] || '/knowledge-list';
    this.db.FetchData(data,'login/user_login')
    .subscribe((data:any) => {
      if(data)
      {
        console.log(data);
        this.nangia_user = data;
        this.nangia_user.nangia_login = true;
        this.db.can_active = '1';
        localStorage.setItem('nangia_user',JSON.stringify(this.nangia_user));
        console.log(this.NextUrl);
        console.log('****LOGIN****');
        this.router.navigate([this.NextUrl]);
      }
      else{
        this.dialog.error('Please check your Username and Password');
      }
    },error=>{
      this.dialog.error('Something went wrong !!! Try Again...');
      console.log(error);
    });
    
  }

}
