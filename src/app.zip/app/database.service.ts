import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { SessionserviceService } from "../app/sessionservice.service";


@Injectable({
  providedIn: 'root'
})
export class DatabaseService {

  

  // MyUrl:string = "http://nextstep.net.in/nangia/";
  // DbUrl:string = "http://nextstep.net.in/nangia/index.php/";

  MyUrl:string = "http://crm.nangia.com/nangia_api/";
  DbUrl:string = "http://crm.nangia.com/nangia_api/index.php/";

  
  permission_array:any=[];
  can_active:string = '';
  token:string = '';
  
  constructor(public http:HttpClient) { }
  header:any = new HttpHeaders();


  FetchData(request_data:any, fn:any)
  {
    // let header = new HttpHeaders();
    // header.append('Content-Type', 'application/json');
    // header.append('Authorization','Bearer ' + this.token);

    let header = new HttpHeaders();

header = header.append('Authorization','Bearer ' + this.token);
header = header.append("Content-Type", "application/x-www-form-urlencoded");
   
    // this.header.append('Authorization','Bearer ' + this.token);
    //this.header.append('Bearer ', );
    // console.log(request_data);
    console.log(this.token);
    return this.http.post(this.DbUrl+fn, JSON.stringify(request_data), {headers:header});
  }

  get_rqst(fn: any) 
  {
    // this.header.append('Content-Type', 'application/json');
    // this.header.append('Authorization', 'Bearer '+this.token);

    let header = new HttpHeaders();
    header = header.append('Authorization','Bearer ' + this.token);
    header = header.append("Content-Type", "application/json");
    console.log(this.token);

    return this.http.get(this.DbUrl + fn, {headers: header});
  }

  FileData(request_data:any, fn:any)
  {
    let header = new HttpHeaders();
    header = header.append('Authorization','Bearer ' + this.token);
    header = header.append("Content-Type", "multipart/encrypted");
    // console.log(this.token);

    // this.header.append('Content-Type',undefined);
    // console.log(request_data);
    // console.log(this.header);
    return this.http.post( this.DbUrl+fn, request_data, {headers : this.header});
  }

  // permission_func(data:any){
  //   this.FetchData({'userid': data},'User/get_user')
  //         .subscribe((result:any)=>{
  //           console.log(result);
  //           return result;
  //         },error=>{
  //           console.log(error);
  //         });
    
  // }
}
