// import { Component, OnInit } from '@angular/core';
import { DatabaseService } from "../../database.service";
import { DialogComponent } from "../../DialogComponent";
import { Router } from '@angular/router';

import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';

@Component({
  selector: 'app-add-sub-category-module',
  templateUrl: './add-sub-category-module.component.html'
})
export class AddSubCategoryModuleComponent implements OnInit {
  form: any = {};
  category2:any = [];
  id:any;
  sendingData = false;
  constructor(public db:DatabaseService,public dialog: DialogComponent,public router:Router,private dialogRef: MatDialogRef< AddSubCategoryModuleComponent>,@ Inject( MAT_DIALOG_DATA) data,public alert: MatDialog) { 

    
this. id = data. id;
this.form.id=this. id;
console. log( this. id);
  }

  ngOnInit() {
    this.getallcat();
  }


  subsavecat(){
    // console.log(this.form);
    this.db.FetchData({'data':this.form},'Category/add_category ')
    .subscribe((result)=>{
      // console.log(result);
      if(result['message'] == "Category Added Successfully"){
        this.dialog.success('category','Added !!!!');
        this.sendingData = true;
        this.router.navigate(['/category-list']);
      }
    },error=>{
      console.log(error);
        this.dialog.error('Something went wrong !!! Try Again...')
    });
    // this.sendingData = false;
      this.alert.closeAll();

  }

  getallcat(){
    this.db.FetchData({},'Category/get_all_category')
    .subscribe((result)=>{
      console.log(result);
      this.category2 = result['data'];
      console.log(this.category2);

    })
  }

}
